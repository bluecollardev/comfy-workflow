#!/bin/sh
# Queue every v20 solve-carry API graph in this folder into the CanalV2 ComfyUI (port 8189), in name order.
# ComfyUI runs them one after another. Output per shot: 80_TEST-BUCKET/corrosion_v20-carry_2026-10-17/<shot>/residual-on/{dpx,review}
# usage:  sh queue_v20.sh            (all)      sh queue_v20.sh corrosion-064   (one)
cd "$(dirname "$0")"
for f in ${1:-corrosion-}*_api.json; do
  python3 -c "import json,sys;json.dump({'prompt':json.load(open(sys.argv[1]))},open('/tmp/_p.json','w'))" "$f"
  echo "$f -> $(curl -s -X POST http://127.0.0.1:8189/prompt -H 'Content-Type: application/json' --data-binary @/tmp/_p.json)"
done
