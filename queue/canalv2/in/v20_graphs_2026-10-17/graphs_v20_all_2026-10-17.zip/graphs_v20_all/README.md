# v20 solve-carry graphs, all corrosion shots (2026-10-17)

One API graph per shot/part, built from Antigravity's corrosion-058 v20 v002 graph by changing only: plate folder/prefix/range,
reference (lead) frame, still (paint), comp mask, sample region (hull mask), output folder and names. Parameters untouched.

Needs: ComfyUI-BH-ShotPipe-v20 upgraded pack (nodes20/solve20 from the zip) loaded; v15 pack beside it.
Run:   sh queue_v20.sh                 queues all 17 in order (058 is included as the v002 graph already run; skip if done)
Output: 80_TEST-BUCKET/corrosion_v20-carry_2026-10-17/<shot>/residual-on/dpx (full DPX), review (2048 jpg), *_report_v001.json

Inputs per shot are in MANIFEST.csv. Shots with no Gen paint use the checker fill (051a/w/b, 111, 122a, 124, 131, 148, 159, 165):
those runs test the solve only. 058 uses the raw Gen + bucket comp mask v002 as Antigravity set it; every other Gen shot uses the
03_WORK gen-aligned / comp-matte-aligned files.
051w = the whip frames 092841-092850, referenced from 092841 so every frame of 051 is represented.
